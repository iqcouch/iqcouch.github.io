#!/bin/bash

## Pe CouchDB local am user root cu parola root
## D'aia folosesc header-ul Authorization
## Daca este admin party atunci scoateti-l

## Baza de date app_test trebuie sa fie creata in prealabil

## Insert an image as attachment to a new document. The document is automatically created
curl -v -X PUT http://127.0.0.1:5984/app_test/pufi/foto.png \
-H 'Authorization: Basic cm9vdDpyb290' -H 'Content-Type:  image/png' \
--data-binary @logo.png

## Insert an image or multiple images as attachemnt base64 encoded.
curl -v -X PUT http://127.0.0.1:5984/app_test/mimi \
-H 'Authorization: Basic cm9vdDpyb290' -H 'Content-Type:  application/json' \
--data @3.txt

## Prepare 0.txt file
cat logo.jpg >> 0.txt
cat 2.txt >> 0.txt
cat logo.png >> 0.txt
cat 1.txt >> 0.txt

## Si nu mai editati sau deschideti cu vre-un editor fisierul 0.txt
## efectul este naspa - caracterele non-printabile sunt transformate
## si datele binare sunt facute muci

## Insert images or multiple images as attachments in binary as multipart/realted document
curl -v -X PUT http://127.0.0.1:5984/app_test/_design/app \
-H 'Authorization: Basic cm9vdDpyb290' \
-H 'Content-Type:  multipart/related; boundary="abc123"' --data-binary @0.txt

